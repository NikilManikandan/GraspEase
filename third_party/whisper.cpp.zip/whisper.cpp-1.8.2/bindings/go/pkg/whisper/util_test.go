package whisper_test

const (
	ModelPath  = "../../models/ggml-small.en.bin"
	SamplePath = "../../samples/jfk.wav"
)
