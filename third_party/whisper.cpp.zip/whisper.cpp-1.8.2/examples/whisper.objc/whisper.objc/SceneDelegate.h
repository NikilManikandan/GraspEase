//
//  SceneDelegate.h
//  whisper.objc
//
//  Created by Georgi Gerganov on 23.10.22.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

